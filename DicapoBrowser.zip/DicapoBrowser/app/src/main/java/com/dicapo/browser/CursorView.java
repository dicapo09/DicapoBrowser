package com.dicapo.browser;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.util.AttributeSet;
import android.view.View;

/** Cursor virtual que se mueve con las flechas del control remoto. */
public class CursorView extends View {

    private float cx = -1, cy = -1;
    private boolean shown = true;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path arrow = new Path();
    private final float scale;

    public CursorView(Context c) { this(c, null); }

    public CursorView(Context c, AttributeSet a) {
        super(c, a);
        scale = getResources().getDisplayMetrics().density * 1.5f;
        fill.setColor(0xFFFFFFFF);
        fill.setStyle(Paint.Style.FILL);
        stroke.setColor(0xFF000000);
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(1.4f * getResources().getDisplayMetrics().density);
        stroke.setStrokeJoin(Paint.Join.ROUND);
        float[] p = {0, 0, 0, 17, 4.2f, 13.2f, 7, 19.5f, 9.6f, 18.4f, 6.9f, 12.2f, 12.5f, 12.2f};
        arrow.moveTo(p[0] * scale, p[1] * scale);
        for (int i = 2; i < p.length; i += 2) arrow.lineTo(p[i] * scale, p[i + 1] * scale);
        arrow.close();
        setFocusable(false);
        setClickable(false);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (cx < 0 || cx > w || cy > h) { cx = w / 2f; cy = h / 2f; }
    }

    @Override
    protected void onDraw(Canvas c) {
        if (!shown) return;
        c.save();
        c.translate(cx, cy);
        c.drawPath(arrow, fill);
        c.drawPath(arrow, stroke);
        c.restore();
    }

    public float getCursorX() { return cx; }
    public float getCursorY() { return cy; }

    public void setShown(boolean s) { shown = s; invalidate(); }

    /** Mueve el cursor; devuelve qué bordes tocó: bit 1 izq, 2 der, 4 arriba, 8 abajo. */
    public int move(float dx, float dy) {
        int w = getWidth(), h = getHeight(), edges = 0;
        float m = 2f;
        cx += dx;
        cy += dy;
        if (cx < m) { cx = m; if (dx < 0) edges |= 1; }
        if (cx > w - m) { cx = w - m; if (dx > 0) edges |= 2; }
        if (cy < m) { cy = m; if (dy < 0) edges |= 4; }
        if (cy > h - m) { cy = h - m; if (dy > 0) edges |= 8; }
        invalidate();
        return edges;
    }
}
