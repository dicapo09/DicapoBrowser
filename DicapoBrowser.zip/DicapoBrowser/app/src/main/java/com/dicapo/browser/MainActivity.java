package com.dicapo.browser;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.text.TextUtils;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewParent;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.net.URLEncoder;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public class MainActivity extends Activity {

    private static final String HOME = "file:///android_asset/home.html";
    private static final String DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) "
                    + "Chrome/126.0.0.0 Safari/537.36";

    private static final String[] ENGINE_NAMES = {"Google", "DuckDuckGo", "Brave Search", "Bing"};
    private static final String[] ENGINE_URLS = {
            "https://www.google.com/search?q=",
            "https://duckduckgo.com/?q=",
            "https://search.brave.com/search?q=",
            "https://www.bing.com/search?q="
    };

    private static final Set<String> AD_HOSTS = new HashSet<>(Arrays.asList(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "google-analytics.com", "googletagmanager.com", "googletagservices.com",
            "adservice.google.com", "adnxs.com", "adsrvr.org", "advertising.com",
            "taboola.com", "outbrain.com", "criteo.com", "criteo.net", "rubiconproject.com",
            "pubmatic.com", "openx.net", "casalemedia.com", "scorecardresearch.com",
            "quantserve.com", "moatads.com", "amazon-adsystem.com", "adform.net",
            "smartadserver.com", "yieldmo.com", "33across.com", "sharethrough.com",
            "teads.tv", "popads.net", "popcash.net", "propellerads.com", "exoclick.com",
            "juicyads.com", "adsterra.com", "mgid.com", "revcontent.com", "zedo.com",
            "media.net", "bidswitch.net", "sovrn.com", "lijit.com", "contextweb.com",
            "onclickads.net", "a-ads.com", "hilltopads.net", "clickadu.com",
            "trafficjunky.net", "adsco.re", "hotjar.com", "yandexadexchange.net",
            "adcash.com", "admaven.com", "ad-maven.com", "inmobi.com", "applovin.com",
            "unityads.unity3d.com", "adcolony.com", "chartboost.com", "vungle.com",
            "serving-sys.com", "imasdk.googleapis.com.ads", "3lift.com", "indexww.com",
            "gumgum.com", "undertone.com", "spotxchange.com", "springserve.com"
    ));

    private WebView web;
    private CursorView cursor;
    private EditText urlBar;
    private ProgressBar progress;
    private View toolbar;
    private FrameLayout fullscreen;
    private View customView;
    private WebChromeClient.CustomViewCallback customCallback;
    private Chrome chrome;
    private SharedPreferences prefs;
    private String defaultUA;
    private long clickDownTime;
    private boolean clickActive;
    private long lastBackPress;

    // ---------------------------------------------------------------- ciclo de vida

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("dicapo", MODE_PRIVATE);

        web = findViewById(R.id.web);
        cursor = findViewById(R.id.cursor);
        urlBar = findViewById(R.id.urlBar);
        progress = findViewById(R.id.progress);
        toolbar = findViewById(R.id.toolbar);
        fullscreen = findViewById(R.id.fullscreen);

        setupToolbar();
        setupWeb();
        cursor.setShown(isCursorMode());
        ensureDefaultBookmarks();

        if (state != null && web.restoreState(state) != null) {
            // estado restaurado
        } else {
            String url = urlFromIntent(getIntent());
            web.loadUrl(url != null ? url : HOME);
        }
        web.requestFocus();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        String url = urlFromIntent(intent);
        if (url != null) web.loadUrl(url);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override
    protected void onPause() {
        super.onPause();
        web.onPause();
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onResume() {
        super.onResume();
        web.onResume();
    }

    @Override
    protected void onDestroy() {
        web.destroy();
        super.onDestroy();
    }

    private String urlFromIntent(Intent i) {
        if (i != null && Intent.ACTION_VIEW.equals(i.getAction()) && i.getData() != null) {
            return i.getData().toString();
        }
        return null;
    }

    // ---------------------------------------------------------------- barra

    private void setupToolbar() {
        findViewById(R.id.btnBack).setOnClickListener(v -> { if (web.canGoBack()) web.goBack(); });
        findViewById(R.id.btnForward).setOnClickListener(v -> { if (web.canGoForward()) web.goForward(); });
        findViewById(R.id.btnReload).setOnClickListener(v -> web.reload());
        findViewById(R.id.btnHome).setOnClickListener(v -> { web.loadUrl(HOME); enterPage(); });
        findViewById(R.id.btnStar).setOnClickListener(v -> addBookmark());
        findViewById(R.id.btnBookmarks).setOnClickListener(v -> showBookmarks());
        findViewById(R.id.btnCursor).setOnClickListener(v -> toggleCursor());
        findViewById(R.id.btnMenu).setOnClickListener(v -> showMenu());

        urlBar.setOnEditorActionListener((v, actionId, event) -> {
            boolean enter = event != null && event.getKeyCode() == KeyEvent.KEYCODE_ENTER
                    && event.getAction() == KeyEvent.ACTION_DOWN;
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE || enter) {
                navigate(urlBar.getText().toString());
                hideKeyboard();
                enterPage();
                return true;
            }
            return false;
        });
    }

    private boolean toolbarHasFocus() {
        View f = getCurrentFocus();
        while (f != null) {
            if (f == toolbar) return true;
            ViewParent p = f.getParent();
            f = (p instanceof View) ? (View) p : null;
        }
        return false;
    }

    private void focusToolbar() {
        findViewById(R.id.btnBack).requestFocus();
    }

    private void enterPage() {
        web.requestFocus();
        cursor.setShown(isCursorMode());
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(urlBar.getWindowToken(), 0);
    }

    // ---------------------------------------------------------------- web

    private void setupWeb() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        defaultUA = s.getUserAgentString().replace("; wv", "");
        applyUserAgent();

        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.setWebViewClient(new Client());
        chrome = new Chrome();
        web.setWebChromeClient(chrome);
        web.setDownloadListener(this::download);
    }

    private void applyUserAgent() {
        web.getSettings().setUserAgentString(prefs.getBoolean("desktop", false) ? DESKTOP_UA : defaultUA);
    }

    private boolean isHome(String url) {
        return url != null && url.startsWith("file:///android_asset/");
    }

    private void navigate(String input) {
        String q = input == null ? "" : input.trim();
        if (q.isEmpty()) return;
        String url;
        boolean hasScheme = q.matches("(?i)^[a-z][a-z0-9+.-]*://.*");
        boolean looksLikeUrl = !q.contains(" ") && (q.contains(".") || q.startsWith("localhost"));
        if (hasScheme) {
            url = q;
        } else if (looksLikeUrl) {
            url = "https://" + q;
        } else {
            url = searchPrefix() + encode(q);
        }
        web.loadUrl(url);
    }

    private String encode(String s) {
        try { return URLEncoder.encode(s, "UTF-8"); } catch (Exception e) { return s; }
    }

    private String searchPrefix() {
        int i = prefs.getInt("engine", 0);
        if (i < 0 || i >= ENGINE_URLS.length) i = 0;
        return ENGINE_URLS[i];
    }

    private boolean isAd(String host) {
        if (host == null || !prefs.getBoolean("adblock", true)) return false;
        host = host.toLowerCase();
        while (true) {
            if (AD_HOSTS.contains(host)) return true;
            int dot = host.indexOf('.');
            if (dot < 0 || dot == host.length() - 1) return false;
            host = host.substring(dot + 1);
        }
    }

    private void renderHome() {
        String js = "render(" + loadBookmarks().toString() + "," + JSONObject.quote(searchPrefix()) + ")";
        web.evaluateJavascript(js, null);
    }

    private class Client extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            return handleUrl(r.getUrl().toString());
        }

        @SuppressWarnings("deprecation")
        @Override
        public boolean shouldOverrideUrlLoading(WebView v, String url) {
            return handleUrl(url);
        }

        private boolean handleUrl(String url) {
            if (url.startsWith("http://") || url.startsWith("https://")
                    || url.startsWith("file:///android_asset/") || url.startsWith("about:")
                    || url.startsWith("data:") || url.startsWith("blob:")) {
                return false;
            }
            try {
                Intent i = url.startsWith("intent:")
                        ? Intent.parseUri(url, Intent.URI_INTENT_SCHEME)
                        : new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                i.addCategory(Intent.CATEGORY_BROWSABLE);
                i.setComponent(null);
                startActivity(i);
            } catch (Exception e) {
                toast("No hay una app para abrir este enlace");
            }
            return true;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            if (isAd(r.getUrl().getHost())) {
                return new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));
            }
            return super.shouldInterceptRequest(v, r);
        }

        @Override
        public void onPageStarted(WebView v, String url, Bitmap favicon) {
            if (!urlBar.hasFocus()) urlBar.setText(isHome(url) ? "" : url);
            progress.setVisibility(View.VISIBLE);
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            if (!urlBar.hasFocus()) urlBar.setText(isHome(url) ? "" : url);
            if (isHome(url)) renderHome();
        }
    }

    private class Chrome extends WebChromeClient {
        @Override
        public void onProgressChanged(WebView v, int p) {
            progress.setProgress(p);
            progress.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) {
            if (customView != null) { cb.onCustomViewHidden(); return; }
            customView = view;
            customCallback = cb;
            fullscreen.addView(view, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));
            fullscreen.setVisibility(View.VISIBLE);
            fullscreen.requestFocus();
        }

        @Override
        public void onHideCustomView() {
            if (customView == null) return;
            fullscreen.removeView(customView);
            fullscreen.setVisibility(View.GONE);
            customView = null;
            if (customCallback != null) customCallback.onCustomViewHidden();
            customCallback = null;
            enterPage();
        }

        @Override
        public Bitmap getDefaultVideoPoster() {
            return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
        }
    }

    // ---------------------------------------------------------------- descargas

    private void download(String url, String userAgent, String disposition, String mime, long length) {
        if (Build.VERSION.SDK_INT >= 23 && Build.VERSION.SDK_INT <= 28
                && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
            toast("Concede el permiso y vuelve a intentar la descarga");
            return;
        }
        try {
            String name = URLUtil.guessFileName(url, disposition, mime);
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
            if (mime != null) r.setMimeType(mime);
            String cookies = CookieManager.getInstance().getCookie(url);
            if (cookies != null) r.addRequestHeader("Cookie", cookies);
            r.addRequestHeader("User-Agent", userAgent);
            r.setTitle(name);
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            if (dm != null) dm.enqueue(r);
            toast("Descargando: " + name);
        } catch (Exception e) {
            toast("No se pudo descargar: " + e.getMessage());
        }
    }

    // ---------------------------------------------------------------- control remoto

    private boolean isCursorMode() { return prefs.getBoolean("cursor", true); }

    private void toggleCursor() {
        boolean on = !isCursorMode();
        prefs.edit().putBoolean("cursor", on).apply();
        toast(on ? "Cursor activado" : "Cursor desactivado (navegación por enlaces)");
        enterPage();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int code = e.getKeyCode();
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;

        // Video en pantalla completa
        if (customView != null) {
            switch (code) {
                case KeyEvent.KEYCODE_BACK:
                    if (!down) chrome.onHideCustomView();
                    return true;
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_ENTER:
                case KeyEvent.KEYCODE_NUMPAD_ENTER:
                    if (down && e.getRepeatCount() == 0) mediaJs("v.paused?v.play():v.pause();");
                    return true;
                case KeyEvent.KEYCODE_DPAD_RIGHT:
                    if (down) mediaJs("v.currentTime+=10;");
                    return true;
                case KeyEvent.KEYCODE_DPAD_LEFT:
                    if (down) mediaJs("v.currentTime-=10;");
                    return true;
                default:
                    break;
            }
        }

        // Teclas multimedia
        switch (code) {
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                if (down) mediaJs("v.paused?v.play():v.pause();");
                return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                if (down) mediaJs("v.play();");
                return true;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                if (down) mediaJs("v.pause();");
                return true;
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
                if (down) mediaJs("v.currentTime+=10;");
                return true;
            case KeyEvent.KEYCODE_MEDIA_REWIND:
                if (down) mediaJs("v.currentTime-=10;");
                return true;
            case KeyEvent.KEYCODE_CHANNEL_UP:
            case KeyEvent.KEYCODE_PAGE_UP:
                if (down) web.pageUp(false);
                return true;
            case KeyEvent.KEYCODE_CHANNEL_DOWN:
            case KeyEvent.KEYCODE_PAGE_DOWN:
                if (down) web.pageDown(false);
                return true;
            case KeyEvent.KEYCODE_MENU:
                if (!down) { if (toolbarHasFocus()) enterPage(); else focusToolbar(); }
                return true;
            case KeyEvent.KEYCODE_BACK:
                if (!down) handleBack();
                return true;
            default:
                break;
        }

        // En la barra: flecha abajo vuelve a la página
        if (toolbarHasFocus()) {
            if (code == KeyEvent.KEYCODE_DPAD_DOWN) {
                if (down) enterPage();
                return true;
            }
            return super.dispatchKeyEvent(e);
        }

        // Modo cursor
        if (isCursorMode()) {
            switch (code) {
                case KeyEvent.KEYCODE_DPAD_UP:
                case KeyEvent.KEYCODE_DPAD_DOWN:
                case KeyEvent.KEYCODE_DPAD_LEFT:
                case KeyEvent.KEYCODE_DPAD_RIGHT:
                    if (down) moveCursor(code, e.getRepeatCount());
                    return true;
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_ENTER:
                case KeyEvent.KEYCODE_NUMPAD_ENTER:
                case KeyEvent.KEYCODE_BUTTON_A:
                    if (down && e.getRepeatCount() == 0) touch(MotionEvent.ACTION_DOWN);
                    else if (!down) touch(MotionEvent.ACTION_UP);
                    return true;
                default:
                    break;
            }
        }
        return super.dispatchKeyEvent(e);
    }

    private void handleBack() {
        if (toolbarHasFocus()) {
            enterPage();
        } else if (web.canGoBack()) {
            web.goBack();
        } else if (!isHome(web.getUrl())) {
            web.loadUrl(HOME);
        } else {
            long now = SystemClock.uptimeMillis();
            if (now - lastBackPress < 2000) {
                finish();
            } else {
                lastBackPress = now;
                toast("Presiona Atrás otra vez para salir");
            }
        }
    }

    private void mediaJs(String action) {
        web.evaluateJavascript("(function(){var v=document.fullscreenElement&&document.fullscreenElement.tagName=='VIDEO'"
                + "?document.fullscreenElement:null;if(!v){var a=document.querySelectorAll('video');"
                + "for(var i=0;i<a.length;i++){if(!a[i].paused||!v)v=a[i];}}if(v){" + action + "}})()", null);
    }

    private void moveCursor(int code, int repeat) {
        cursor.setShown(true);
        float d = getResources().getDisplayMetrics().density;
        float step = d * (9 + Math.min(repeat, 25) * 2.2f);
        float dx = 0, dy = 0;
        if (code == KeyEvent.KEYCODE_DPAD_LEFT) dx = -step;
        if (code == KeyEvent.KEYCODE_DPAD_RIGHT) dx = step;
        if (code == KeyEvent.KEYCODE_DPAD_UP) dy = -step;
        if (code == KeyEvent.KEYCODE_DPAD_DOWN) dy = step;

        int edges = cursor.move(dx, dy);
        hover();
        if (edges != 0) {
            float scale = webScale();
            int sx = 0, sy = 0;
            int amountY = (int) (web.getHeight() * 0.18f / scale);
            int amountX = (int) (web.getWidth() * 0.18f / scale);
            if ((edges & 1) != 0) sx = -amountX;
            if ((edges & 2) != 0) sx = amountX;
            if ((edges & 4) != 0) sy = -amountY;
            if ((edges & 8) != 0) sy = amountY;
            scrollPage(sx, sy);
        }
    }

    @SuppressWarnings("deprecation")
    private float webScale() {
        float s = web.getScale();
        return s > 0 ? s : 1f;
    }

    private void scrollPage(final int dx, final int dy) {
        float scale = webScale();
        int x = (int) (cursor.getCursorX() / scale);
        int y = (int) (cursor.getCursorY() / scale);
        String js = "(function(x,y,dx,dy){var el=document.elementFromPoint(x,y);"
                + "while(el&&el!==document.body&&el!==document.documentElement){var st=getComputedStyle(el);"
                + "if(dy&&/(auto|scroll)/.test(st.overflowY)&&el.scrollHeight>el.clientHeight){var b=el.scrollTop;el.scrollTop+=dy;if(el.scrollTop!=b)return 1;}"
                + "if(dx&&/(auto|scroll)/.test(st.overflowX)&&el.scrollWidth>el.clientWidth){var c=el.scrollLeft;el.scrollLeft+=dx;if(el.scrollLeft!=c)return 1;}"
                + "el=el.parentElement;}"
                + "var sx=window.scrollX,sy=window.scrollY;window.scrollBy(dx,dy);"
                + "return (window.scrollX!=sx||window.scrollY!=sy)?1:0;})("
                + x + "," + y + "," + dx + "," + dy + ")";
        web.evaluateJavascript(js, result -> {
            if ("0".equals(result) && dy < 0) {
                if (web.canScrollVertically(-1)) web.scrollBy(0, -web.getHeight() / 5);
                else focusToolbar();
            } else if ("0".equals(result) || result == null || "null".equals(result)) {
                web.scrollBy((int) (dx * webScale()), (int) (dy * webScale()));
            }
        });
    }

    private void touch(int action) {
        long now = SystemClock.uptimeMillis();
        if (action == MotionEvent.ACTION_DOWN) {
            clickDownTime = now;
            clickActive = true;
            web.requestFocus();
        } else if (!clickActive) {
            return;
        } else {
            clickActive = false;
        }
        MotionEvent.PointerProperties[] props = {new MotionEvent.PointerProperties()};
        props[0].id = 0;
        props[0].toolType = MotionEvent.TOOL_TYPE_FINGER;
        MotionEvent.PointerCoords[] coords = {new MotionEvent.PointerCoords()};
        coords[0].x = cursor.getCursorX();
        coords[0].y = cursor.getCursorY();
        coords[0].pressure = 1f;
        coords[0].size = 1f;
        MotionEvent ev = MotionEvent.obtain(clickDownTime, now, action, 1, props, coords,
                0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_TOUCHSCREEN, 0);
        web.dispatchTouchEvent(ev);
        ev.recycle();
    }

    private void hover() {
        MotionEvent.PointerProperties[] props = {new MotionEvent.PointerProperties()};
        props[0].id = 0;
        props[0].toolType = MotionEvent.TOOL_TYPE_MOUSE;
        MotionEvent.PointerCoords[] coords = {new MotionEvent.PointerCoords()};
        coords[0].x = cursor.getCursorX();
        coords[0].y = cursor.getCursorY();
        long now = SystemClock.uptimeMillis();
        MotionEvent ev = MotionEvent.obtain(now, now, MotionEvent.ACTION_HOVER_MOVE, 1, props, coords,
                0, 0, 1f, 1f, 0, 0, InputDevice.SOURCE_MOUSE, 0);
        web.dispatchGenericMotionEvent(ev);
        ev.recycle();
    }

    // ---------------------------------------------------------------- favoritos

    private JSONArray loadBookmarks() {
        try { return new JSONArray(prefs.getString("bookmarks", "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    private void saveBookmarks(JSONArray a) {
        prefs.edit().putString("bookmarks", a.toString()).apply();
        if (isHome(web.getUrl())) renderHome();
    }

    private void ensureDefaultBookmarks() {
        if (prefs.contains("bookmarks")) return;
        String[][] defs = {
                {"YouTube", "https://m.youtube.com/"},
                {"Google", "https://www.google.com/"},
                {"Brave Search", "https://search.brave.com/"},
                {"Wikipedia", "https://es.wikipedia.org/"},
                {"Twitch", "https://m.twitch.tv/"},
                {"Gmail", "https://mail.google.com/"}
        };
        JSONArray a = new JSONArray();
        try {
            for (String[] d : defs) a.put(new JSONObject().put("t", d[0]).put("u", d[1]));
        } catch (Exception ignored) { }
        prefs.edit().putString("bookmarks", a.toString()).apply();
    }

    private void addBookmark() {
        String url = web.getUrl();
        if (url == null || isHome(url)) { toast("Abre una página para guardarla"); return; }
        JSONArray a = loadBookmarks();
        for (int i = 0; i < a.length(); i++) {
            if (url.equals(a.optJSONObject(i).optString("u"))) { toast("Ya está en favoritos"); return; }
        }
        String title = web.getTitle();
        if (TextUtils.isEmpty(title)) title = Uri.parse(url).getHost();
        try { a.put(new JSONObject().put("t", title).put("u", url)); } catch (Exception ignored) { }
        saveBookmarks(a);
        toast("Agregado a favoritos");
    }

    private void showBookmarks() {
        final JSONArray a = loadBookmarks();
        if (a.length() == 0) { toast("No tienes favoritos"); return; }
        String[] names = new String[a.length()];
        for (int i = 0; i < a.length(); i++) names[i] = a.optJSONObject(i).optString("t");
        dialog().setTitle("Favoritos")
                .setItems(names, (d, which) -> bookmarkOptions(a, which))
                .setNegativeButton("Cerrar", null)
                .show();
    }

    private void bookmarkOptions(final JSONArray a, final int index) {
        final JSONObject b = a.optJSONObject(index);
        dialog().setTitle(b.optString("t"))
                .setItems(new String[]{"Abrir", "Eliminar"}, (d, which) -> {
                    if (which == 0) {
                        web.loadUrl(b.optString("u"));
                        enterPage();
                    } else {
                        JSONArray n = new JSONArray();
                        for (int i = 0; i < a.length(); i++) if (i != index) n.put(a.optJSONObject(i));
                        saveBookmarks(n);
                        toast("Eliminado");
                    }
                })
                .show();
    }

    // ---------------------------------------------------------------- menú

    private void showMenu() {
        String[] items = {
                "Modo cursor: " + (isCursorMode() ? "Sí" : "No"),
                "Modo escritorio: " + (prefs.getBoolean("desktop", false) ? "Sí" : "No"),
                "Bloqueador de anuncios: " + (prefs.getBoolean("adblock", true) ? "Sí" : "No"),
                "Buscador: " + ENGINE_NAMES[Math.max(0, Math.min(prefs.getInt("engine", 0), ENGINE_NAMES.length - 1))],
                "Borrar datos de navegación",
                "Acerca de"
        };
        dialog().setTitle("Menú").setItems(items, (d, which) -> {
            switch (which) {
                case 0:
                    toggleCursor();
                    break;
                case 1:
                    prefs.edit().putBoolean("desktop", !prefs.getBoolean("desktop", false)).apply();
                    applyUserAgent();
                    web.reload();
                    break;
                case 2:
                    prefs.edit().putBoolean("adblock", !prefs.getBoolean("adblock", true)).apply();
                    web.reload();
                    break;
                case 3:
                    chooseEngine();
                    break;
                case 4:
                    clearData();
                    break;
                default:
                    String v = "";
                    try { v = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
                    catch (Exception ignored) { }
                    dialog().setTitle("Dicapo Browser")
                            .setMessage("Versión " + v + "\nNavegador para Android TV.")
                            .setPositiveButton("OK", null).show();
            }
        }).setNegativeButton("Cerrar", null).show();
    }

    private void chooseEngine() {
        dialog().setTitle("Buscador")
                .setSingleChoiceItems(ENGINE_NAMES, prefs.getInt("engine", 0), (d, which) -> {
                    prefs.edit().putInt("engine", which).apply();
                    d.dismiss();
                    if (isHome(web.getUrl())) renderHome();
                    toast("Buscador: " + ENGINE_NAMES[which]);
                }).show();
    }

    private void clearData() {
        dialog().setTitle("Borrar datos")
                .setMessage("Se borrarán caché, cookies, sesiones e historial. Los favoritos se mantienen.")
                .setPositiveButton("Borrar", (d, w) -> {
                    web.clearCache(true);
                    web.clearHistory();
                    CookieManager.getInstance().removeAllCookies(null);
                    CookieManager.getInstance().flush();
                    WebStorage.getInstance().deleteAllData();
                    toast("Datos borrados");
                    web.loadUrl(HOME);
                })
                .setNegativeButton("Cancelar", null).show();
    }

    // ---------------------------------------------------------------- utilidades

    private AlertDialog.Builder dialog() {
        return new AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }
}
