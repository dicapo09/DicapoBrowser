# Dicapo Browser

Navegador web para Android TV (también funciona en teléfonos y tablets).

## Funciones
- Cursor virtual con el control remoto (acelera si mantienes la flecha)
- Página de inicio con favoritos en mosaico y buscador
- Bloqueador de anuncios integrado (se puede apagar)
- Modo escritorio
- Elección de buscador: Google, DuckDuckGo, Brave Search o Bing
- Video en pantalla completa con control de reproducción
- Descargas (por ejemplo, APKs) a la carpeta Descargas
- Aparece en el inicio de Android TV con su propio banner

## Controles
| Botón | Acción |
|---|---|
| Flechas | Mover el cursor; en el borde, desplaza la página |
| OK | Clic (mantener = clic largo) |
| Arriba en el borde superior | Ir a la barra de herramientas |
| Abajo (en la barra) | Volver a la página |
| Atrás | Página anterior / salir (dos veces) |
| Canal + / Canal − | Subir / bajar página |
| Play/Pausa, ⏩, ⏪ | Controlar el video |
| Menú | Alternar entre barra y página |

En pantalla completa: OK = pausa/play, izquierda/derecha = ±10 s, Atrás = salir.

## Compilar
Cada `push` a `main` ejecuta GitHub Actions, que compila el APK y lo publica como Release.

Enlace de descarga directa (sin iniciar sesión), reemplazando USUARIO y REPO:

```
https://github.com/USUARIO/REPO/releases/latest/download/DicapoBrowser.apk
```

Ese enlace sirve en la app **Downloader** de la TV.

## Firma
El APK se firma con `app/dicapo.keystore` (incluido) para que las actualizaciones se instalen encima sin desinstalar.
